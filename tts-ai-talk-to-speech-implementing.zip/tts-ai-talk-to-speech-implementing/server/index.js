const express = require('express');
const multer = require('multer');
const path = require('path');
const { transcribeAudio } = require('./openai');
const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
require('dotenv').config();

const app = express();
const port = process.env.PORT || 5000;

// Configure R2 client
const s3 = new S3Client({
    region: "auto",
    endpoint: `https://${process.env.CLOUDFLARE_ACCOUNT_ID}.r2.cloudflarestorage.com`,
    credentials: {
        accessKeyId: process.env.R2_ACCESS_KEY_ID,
        secretAccessKey: process.env.R2_SECRET_ACCESS_KEY,
    },
});

// Configure multer for file uploads
const storage = multer.memoryStorage(); // Store file in memory
const upload = multer({ storage });

// Route to handle speech-to-text conversion and R2 upload
app.post('/api/speech-to-text', upload.single('audio'), async (req, res) => {
    if (!req.file) {
        return res.status(400).send('No audio file uploaded.');
    }

    try {
        // Transcribe audio
        const transcription = await transcribeAudio(req.file.buffer);

        // Upload audio to R2
        const fileName = `${Date.now()}-${req.file.originalname}`;
        const command = new PutObjectCommand({
            Bucket: process.env.R2_BUCKET_NAME,
            Key: fileName,
            Body: req.file.buffer,
            ContentType: req.file.mimetype,
        });

        await s3.send(command);
        console.log(`File uploaded to R2: ${fileName}`);

        // Send response
        res.json({
            text: transcription,
            fileName: fileName
        });
    } catch (error) {
        console.error('Error processing audio or uploading to R2:', error);
        res.status(500).send('Error processing audio or uploading to R2');
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});