const axios = require('axios');
import OpenAI from "openai";
const FormData = require('form-data');
require('dotenv').config();

const apiKey = process.env.OPENAI_API_KEY;

if (!apiKey) {
    console.error('API key is missing. Please set it in your .env file.');
    process.exit(1);
}

const transcribeAudio = async (audioBuffer) => {
    try {
        const formData = new FormData();
        formData.append('file', audioBuffer, {
            filename: 'audio.mp3',
            contentType: 'audio/mpeg',
        });
        formData.append('model', 'whisper-1');

        // const response = await axios.post('https://api.openai.com/v1/audio/transcriptions', formData, {
        //     headers: {
        //         ...formData.getHeaders(),
        //         'Authorization': `Bearer ${apiKey}`,
        //     },
        //     timeout: 20000, // Increase timeout to 20 seconds
        // });
        //
        // return response.data.text;
    } catch (error) {
        if (error.code === 'ECONNABORTED') {
            console.error('Error transcribing audio: Request timed out');
        } else if (error.response) {
            console.error('Error transcribing audio:', error.response.data);
        } else {
            console.error('Error transcribing audio:', error.message);
        }
        throw error;
    }
};

module.exports = { transcribeAudio };