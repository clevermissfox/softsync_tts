import { useState, useRef, useCallback } from 'react';
import axios from 'axios';

function App() {
    const [isListening, setIsListening] = useState(false);
    const [responseText, setResponseText] = useState('');
    const [error, setError] = useState(null);
    const mediaRecorderRef = useRef(null);
    const audioChunksRef = useRef([]);

    const startListening = useCallback(async () => {
        setIsListening(true);
        setError(null);
        audioChunksRef.current = [];

        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorderRef.current = new MediaRecorder(stream);

            mediaRecorderRef.current.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    audioChunksRef.current.push(event.data);
                }
            };

            mediaRecorderRef.current.onerror = (error) => {
                console.error('MediaRecorder error:', error);
                setError(error.message || 'An error occurred while recording.');
                stopListening();
            };

            mediaRecorderRef.current.onstop = async () => {
                const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
                await processAudio(audioBlob);
            };

            mediaRecorderRef.current.start(250); // Collect data every 250ms
        } catch (error) {
            console.error('Error starting recording:', error);
            setError(error.message || 'An error occurred while starting the recording.');
            setIsListening(false);
        }
    }, []);

    const stopListening = useCallback(() => {
        if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
            mediaRecorderRef.current.stop();
            mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
        }
    }, []);

    const processAudio = async (audioBlob) => {
        try {
            const formData = new FormData();
            formData.append('audio', audioBlob, 'recording.webm');

            const response = await axios.post('/api/speech-to-text', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });
            setResponseText(response.data.text);
        } catch (error) {
            console.error('Error processing audio:', error);
            setError(error.message || 'An error occurred while processing the audio.');
        } finally {
            setIsListening(false);
        }
    };

    return (
        <div>
            <h1>Speech-to-Text Example</h1>
            <button onClick={startListening} disabled={isListening}>
                Start Listening
            </button>
            <button onClick={stopListening} disabled={!isListening}>
                Stop Listening
            </button>
            {error && <p style={{ color: 'red' }}>Error: {error}</p>}
            {responseText && <p>Transcription: {responseText}</p>}
        </div>
    );
}

export default App;